let score = 0;
let targetNumber = generateRandomNumber();
let attempts = 0;

function generateRandomNumber() {
    return Math.floor(Math.random() * 200) + 1;
}

function checkGuess() {
    const guessInput = document.getElementById('guessInput');
    const guess = parseInt(guessInput.value);

    if (guess === targetNumber) {
        score += 1;
        attempts = 0;
        document.getElementById('result').innerText = "Parabéns! Você acertou!";
        document.getElementById('score').innerText = `Pontuação: ${score}`;
        document.getElementById('winnerImg').style.display = 'block';
        targetNumber = generateRandomNumber();
    } else {
        attempts += 1;
        let hint = guess > targetNumber ? "Tente um número menor." : "Tente um número maior.";
        document.getElementById('result').innerText = `Você errou. ${hint}`;
    }
}
